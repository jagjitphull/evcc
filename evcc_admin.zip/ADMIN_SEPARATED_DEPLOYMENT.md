# Evidence Custodian - Separated Admin Deployment Guide

## Architecture

```
                    Internet
                        │
                        ▼
    ┌───────────────────────────────────────────────────────┐
    │                   Linode Server                        │
    │                                                        │
    │  ┌─────────────────┐      ┌─────────────────────────┐ │
    │  │  nginx (public) │      │  nginx-admin (restricted)│ │
    │  │  Port 80/443    │      │  Port 8443               │ │
    │  └────────┬────────┘      └────────────┬────────────┘ │
    │           │                            │              │
    │           ▼                            ▼              │
    │  ┌─────────────────┐      ┌─────────────────────────┐ │
    │  │  evidence-app   │      │  evidence-admin          │ │
    │  │  (Flask:8000)   │      │  (Flask:8001)            │ │
    │  │  User functions │      │  Admin functions         │ │
    │  └────────┬────────┘      └────────────┬────────────┘ │
    │           │                            │              │
    │           └──────────┬─────────────────┘              │
    │                      │                                │
    │           ┌──────────▼──────────┐                     │
    │           │   Shared Volumes    │                     │
    │           │  - evidence-data    │                     │
    │           │  - evidence-uploads │                     │
    │           │  - evidence-output  │                     │
    │           └─────────────────────┘                     │
    └───────────────────────────────────────────────────────┘
```

## Security Benefits

| Feature | Bundled | Separated |
|---------|---------|-----------|
| Admin on separate port | ❌ | ✅ Port 8443 |
| IP restriction possible | Limited | ✅ Easy |
| Network isolation | ❌ | ✅ Separate networks |
| Attack surface | Larger | Smaller per container |
| Can disable admin | ❌ | ✅ Stop container |

---

## Deployment Steps

### 1. Upload Files to Server

```bash
cd /opt/evidence-custodian
# Upload the tarball
tar -xf evidence_custodian_separated.tar
```

### 2. Configure Environment

```bash
# Edit .env file
nano .env

# Add admin-specific secret key (optional but recommended)
# ADMIN_SECRET_KEY=different-secret-key-for-admin
```

### 3. Update SSL Certificate Domain

```bash
# Edit admin nginx config
nano docker/nginx/conf.d/admin.conf

# Update the certificate paths if your domain is different:
# ssl_certificate /etc/letsencrypt/live/YOUR_DOMAIN/fullchain.pem;
# ssl_certificate_key /etc/letsencrypt/live/YOUR_DOMAIN/privkey.pem;
```

### 4. Build and Start All Containers

```bash
docker compose -f docker-compose.production.yml build
docker compose -f docker-compose.production.yml up -d
```

### 5. Verify All Containers Running

```bash
docker compose -f docker-compose.production.yml ps

# Should show:
# evidence-app         running (healthy)
# evidence-admin       running (healthy)
# evidence-nginx       running (healthy)
# evidence-nginx-admin running
# evidence-certbot     running
```

### 6. Open Firewall Port for Admin

```bash
# Allow admin port (restricted to your IP ideally)
sudo ufw allow 8443/tcp

# Or restrict to specific IP:
sudo ufw allow from YOUR.IP.ADDRESS to any port 8443
```

### 7. Create First Admin User

```bash
# Visit admin setup page:
https://evidence.gnugroup.org:8443/setup
```

---

## Access URLs

| Interface | URL | Purpose |
|-----------|-----|---------|
| Main App | https://evidence.gnugroup.org | User registration, login, upload |
| Admin Panel | https://evidence.gnugroup.org:8443 | User management, system admin |
| Admin Setup | https://evidence.gnugroup.org:8443/setup | First admin creation |

---

## IP Restriction (Recommended)

Edit `docker/nginx/conf.d/admin.conf` and uncomment/modify:

```nginx
# Only allow specific IPs
allow 192.168.1.0/24;      # Your local network
allow YOUR.OFFICE.IP;       # Your office IP
allow YOUR.HOME.IP;         # Your home IP
deny all;                   # Block everyone else
```

Then reload:
```bash
docker compose -f docker-compose.production.yml restart nginx-admin
```

---

## Management Commands

### Container Management

```bash
# Start all
docker compose -f docker-compose.production.yml up -d

# Stop all
docker compose -f docker-compose.production.yml down

# Restart just admin
docker compose -f docker-compose.production.yml restart admin nginx-admin

# View admin logs
docker compose -f docker-compose.production.yml logs -f admin

# Disable admin temporarily (security)
docker compose -f docker-compose.production.yml stop admin nginx-admin
```

### Check Status

```bash
# All containers
docker compose -f docker-compose.production.yml ps

# Main app health
curl -I https://evidence.gnugroup.org/health

# Admin health
curl -I https://evidence.gnugroup.org:8443/health
```

---

## Troubleshooting

### Admin Container Won't Start

```bash
# Check logs
docker compose -f docker-compose.production.yml logs admin

# Common issues:
# - Database not initialized (main app must run first)
# - Volume permission issues
```

### Cannot Access Admin Port

```bash
# Check firewall
sudo ufw status

# Check if port is listening
sudo ss -tlnp | grep 8443

# Check nginx-admin logs
docker compose -f docker-compose.production.yml logs nginx-admin
```

### SSL Certificate Issues on Admin

```bash
# Verify cert exists
ls -la certbot-etc/live/evidence.gnugroup.org/

# Update admin.conf with correct domain
nano docker/nginx/conf.d/admin.conf
```

---

## Container Summary

| Container | Port | Network | Purpose |
|-----------|------|---------|---------|
| evidence-app | 8000 | app-network, external | Main application |
| evidence-admin | 8001 | admin-network | Admin panel |
| evidence-nginx | 80, 443 | app-network, external | Public proxy |
| evidence-nginx-admin | 8443 | admin-network | Admin proxy |
| evidence-certbot | - | external | SSL renewal |

---

## Rollback to Bundled Version

If you prefer the simpler bundled setup:

```bash
# Use the bundled docker-compose instead
docker compose -f docker-compose.bundled.yml up -d
```
