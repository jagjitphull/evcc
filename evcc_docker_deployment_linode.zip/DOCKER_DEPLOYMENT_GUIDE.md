# Evidence Custodian - Containerized Deployment Guide

## Overview

Deploy Evidence Custodian as a containerized application on Linode with:
- **Docker** & **Docker Compose** for container orchestration
- **Nginx** reverse proxy with SSL/TLS
- **Let's Encrypt** for free SSL certificates
- **Automatic certificate renewal**

---

## Architecture

```
                    ┌─────────────────────────────────────────┐
                    │              Linode Server              │
                    │                                         │
   Internet ───────►│  ┌─────────────────────────────────┐   │
                    │  │         Nginx Container          │   │
                    │  │    (SSL/TLS, Reverse Proxy)      │   │
                    │  │         Ports: 80, 443           │   │
                    │  └──────────────┬──────────────────┘   │
                    │                 │                       │
                    │                 ▼                       │
                    │  ┌─────────────────────────────────┐   │
                    │  │      Application Container       │   │
                    │  │   (Gunicorn + Flask App)         │   │
                    │  │         Port: 8000               │   │
                    │  └──────────────┬──────────────────┘   │
                    │                 │                       │
                    │                 ▼                       │
                    │  ┌─────────────────────────────────┐   │
                    │  │       Docker Volumes            │   │
                    │  │  (data, uploads, output, logs)   │   │
                    │  └─────────────────────────────────┘   │
                    │                                         │
                    │  ┌─────────────────────────────────┐   │
                    │  │      Certbot Container          │   │
                    │  │   (SSL Certificate Renewal)      │   │
                    │  └─────────────────────────────────┘   │
                    └─────────────────────────────────────────┘
```

---

## Prerequisites

1. **Linode Account** - https://cloud.linode.com
2. **Domain Name** - Pointing to your Linode IP
3. **Local Machine** - With Docker (for building images)

---

## Quick Start

### Option A: Automated Deployment

```bash
# 1. SSH into your Linode
ssh root@YOUR_LINODE_IP

# 2. Download and run deployment script
curl -O https://raw.githubusercontent.com/your-repo/deploy-docker.sh
chmod +x deploy-docker.sh
./deploy-docker.sh

# 3. Follow the prompts
```

### Option B: Manual Deployment

Follow the step-by-step guide below.

---

## Step 1: Create Linode Instance

1. Log in to [Linode Cloud Manager](https://cloud.linode.com)
2. Click **Create Linode**
3. Configure:
   - **Image**: Ubuntu 24.04 LTS
   - **Region**: Mumbai (ap-west) for India
   - **Plan**: Linode 4GB ($24/month) recommended for Docker
   - **Label**: `evidence-custodian-docker`
   - **Root Password**: Strong password
   - **SSH Keys**: Add your public key

4. Click **Create Linode**
5. Note the **IP Address**

---

## Step 2: Configure DNS

Add an A record:

| Type | Host | Value | TTL |
|------|------|-------|-----|
| A | evidence | YOUR_LINODE_IP | 300 |

Wait 5-10 minutes for propagation.

Verify:
```bash
dig evidence.yourdomain.com +short
```

---

## Step 3: Initial Server Setup

```bash
# SSH into server
ssh root@YOUR_LINODE_IP

# Update system
apt update && apt upgrade -y

# Set timezone
timedatectl set-timezone Asia/Kolkata

# Install Docker
curl -fsSL https://get.docker.com | sh
systemctl enable docker
systemctl start docker

# Verify Docker
docker --version
docker compose version

# Configure firewall
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw enable
```

---

## Step 4: Deploy Application

### Create Application Directory

```bash
mkdir -p /opt/evidence-custodian
cd /opt/evidence-custodian
```

### Upload Application Files

From your local machine:
```bash
# Create deployment package
tar -cvf evidence_custodian_docker.tar \
    Dockerfile.production \
    docker-compose.production.yml \
    docker/ \
    web_ui/ \
    tools/ \
    main.py \
    requirements.production.txt \
    .env.example

# Upload to server
scp evidence_custodian_docker.tar root@YOUR_IP:/opt/evidence-custodian/
```

### Extract and Configure

```bash
cd /opt/evidence-custodian
tar -xf evidence_custodian_docker.tar

# Create environment file
cp .env.example .env

# Generate secret key
SECRET_KEY=$(openssl rand -hex 32)
sed -i "s/your-super-secret-key-change-in-production/$SECRET_KEY/" .env

# Edit configuration
nano .env
```

### Environment Configuration

```bash
# /opt/evidence-custodian/.env

# Security
SECRET_KEY=your-generated-key-here

# Email (optional - configure for email verification)
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=true
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-password
MAIL_DEFAULT_SENDER=Evidence Custodian <your-email@gmail.com>
EMAIL_VERIFICATION_ENABLED=true
```

---

## Step 5: Build and Start Containers

```bash
cd /opt/evidence-custodian

# Build containers
docker compose -f docker-compose.production.yml build

# Start containers (HTTP only initially)
docker compose -f docker-compose.production.yml up -d

# Check status
docker compose -f docker-compose.production.yml ps

# View logs
docker compose -f docker-compose.production.yml logs -f
```

---

## Step 6: Setup SSL Certificate

### Obtain Certificate

```bash
cd /opt/evidence-custodian
chmod +x docker/init-ssl.sh

# Run SSL setup
./docker/init-ssl.sh evidence.yourdomain.com admin@yourdomain.com

# For testing, use staging environment first:
# ./docker/init-ssl.sh evidence.yourdomain.com admin@yourdomain.com --staging
```

### Verify SSL

```bash
# Check certificate
curl -I https://evidence.yourdomain.com

# Test SSL grade
# Visit: https://www.ssllabs.com/ssltest/analyze.html?d=evidence.yourdomain.com
```

---

## Step 7: Verify Deployment

```bash
# Check all containers are running
docker compose -f docker-compose.production.yml ps

# Check application health
curl -I https://evidence.yourdomain.com/health

# Check login page
curl -I https://evidence.yourdomain.com/login
```

### Browser Test

1. Open https://evidence.yourdomain.com
2. Verify SSL certificate (padlock icon)
3. Register a new account
4. Verify CAPTCHA works
5. Test file upload

---

## Management Commands

### Container Management

```bash
# Start all containers
docker compose -f docker-compose.production.yml up -d

# Stop all containers
docker compose -f docker-compose.production.yml down

# Restart specific container
docker compose -f docker-compose.production.yml restart app

# View logs
docker compose -f docker-compose.production.yml logs -f app
docker compose -f docker-compose.production.yml logs -f nginx

# Execute command in container
docker compose -f docker-compose.production.yml exec app bash
```

### Update Application

```bash
cd /opt/evidence-custodian

# Pull latest code (if using git)
git pull

# Rebuild and restart
docker compose -f docker-compose.production.yml build
docker compose -f docker-compose.production.yml up -d
```

### Backup Data

```bash
# Backup volumes
docker run --rm \
    -v evidence-custodian_evidence-data:/data \
    -v $(pwd)/backups:/backup \
    alpine tar czf /backup/data-$(date +%Y%m%d).tar.gz -C /data .

# Backup database specifically
docker compose -f docker-compose.production.yml exec app \
    cp /app/data/evidence_custodian.db /app/data/backup_$(date +%Y%m%d).db
```

### View Certificate Status

```bash
# Check certificate expiry
docker compose -f docker-compose.production.yml run --rm certbot certificates

# Manual renewal (usually automatic)
docker compose -f docker-compose.production.yml run --rm certbot renew
docker compose -f docker-compose.production.yml exec nginx nginx -s reload
```

---

## Troubleshooting

### Container Won't Start

```bash
# Check logs
docker compose -f docker-compose.production.yml logs app

# Check if ports are in use
netstat -tlnp | grep -E '80|443|8000'

# Rebuild from scratch
docker compose -f docker-compose.production.yml down -v
docker compose -f docker-compose.production.yml build --no-cache
docker compose -f docker-compose.production.yml up -d
```

### SSL Certificate Issues

```bash
# Check certificate files exist
docker compose -f docker-compose.production.yml exec nginx \
    ls -la /etc/letsencrypt/live/

# Verify nginx config
docker compose -f docker-compose.production.yml exec nginx nginx -t

# Re-obtain certificate
docker compose -f docker-compose.production.yml run --rm certbot \
    certonly --webroot \
    -w /var/www/certbot \
    -d evidence.yourdomain.com \
    --force-renewal
```

### 502 Bad Gateway

```bash
# Check app container is running
docker compose -f docker-compose.production.yml ps

# Check app container logs
docker compose -f docker-compose.production.yml logs app

# Check network connectivity
docker compose -f docker-compose.production.yml exec nginx \
    wget -qO- http://app:8000/health
```

### Permission Issues

```bash
# Fix volume permissions
docker compose -f docker-compose.production.yml exec app \
    chmod -R 777 /app/uploads /app/output /app/data /app/logs
```

---

## Resource Requirements

| Component | CPU | RAM | Disk |
|-----------|-----|-----|------|
| App Container | 1 core | 1 GB | 1 GB |
| Nginx Container | 0.5 core | 256 MB | 100 MB |
| Certbot Container | 0.1 core | 128 MB | 50 MB |
| **Recommended Linode** | 2 cores | 4 GB | 80 GB |

---

## Security Checklist

- [ ] Changed SECRET_KEY from default
- [ ] SSL certificate installed and working
- [ ] Firewall configured (only 22, 80, 443 open)
- [ ] Email configured with app password
- [ ] Regular backups configured
- [ ] Log rotation enabled (Docker handles this)
- [ ] Container images updated regularly

---

## Costs

| Resource | Monthly Cost |
|----------|-------------|
| Linode 4GB | $24 |
| Domain | ~$1-2 |
| SSL (Let's Encrypt) | Free |
| **Total** | ~$25-27/month |

---

## File Structure

```
/opt/evidence-custodian/
├── docker-compose.production.yml
├── Dockerfile.production
├── .env                          # Environment configuration
├── docker/
│   ├── nginx/
│   │   ├── nginx.conf
│   │   └── conf.d/
│   │       ├── app.conf          # HTTPS config (after SSL)
│   │       └── proxy_params.conf
│   ├── init-ssl.sh
│   └── deploy-docker.sh
├── web_ui/
├── tools/
├── requirements.production.txt
└── backups/                      # Backup directory
```

---

## Next Steps

1. ✅ Configure monitoring (Uptime Robot, etc.)
2. ✅ Set up log aggregation
3. ✅ Configure automated backups
4. ✅ Set up CI/CD pipeline
5. ✅ Add custom branding
