# Evidence Custodian - Docker Deployment Quick Reference

## 🚀 5-Minute Deploy

```bash
# 1. SSH to fresh Ubuntu 24.04 Linode
ssh root@YOUR_IP

# 2. Install Docker
curl -fsSL https://get.docker.com | sh

# 3. Setup firewall
ufw allow 22,80,443/tcp && ufw enable

# 4. Create app directory
mkdir -p /opt/evidence-custodian && cd /opt/evidence-custodian

# 5. Upload files (from local machine)
scp evidence_custodian_docker.tar root@YOUR_IP:/opt/evidence-custodian/

# 6. Extract & configure
tar -xf evidence_custodian_docker.tar
cp .env.example .env
nano .env  # Set SECRET_KEY

# 7. Build & start
docker compose -f docker-compose.production.yml up -d --build

# 8. Get SSL certificate
./docker/init-ssl.sh YOUR_DOMAIN YOUR_EMAIL

# 9. Done! Visit https://YOUR_DOMAIN
```

---

## Essential Commands

| Action | Command |
|--------|---------|
| Start | `docker compose -f docker-compose.production.yml up -d` |
| Stop | `docker compose -f docker-compose.production.yml down` |
| Restart | `docker compose -f docker-compose.production.yml restart` |
| Logs | `docker compose -f docker-compose.production.yml logs -f` |
| Status | `docker compose -f docker-compose.production.yml ps` |
| Rebuild | `docker compose -f docker-compose.production.yml up -d --build` |
| Shell | `docker compose -f docker-compose.production.yml exec app bash` |

---

## Container Overview

| Container | Port | Purpose |
|-----------|------|---------|
| evidence-app | 8000 | Flask + Gunicorn |
| evidence-nginx | 80, 443 | Reverse Proxy + SSL |
| evidence-certbot | - | SSL Renewal |

---

## Environment Variables (.env)

```bash
SECRET_KEY=generate-with-openssl-rand-hex-32
MAIL_SERVER=smtp.gmail.com
MAIL_PORT=587
MAIL_USE_TLS=true
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=your-app-password
EMAIL_VERIFICATION_ENABLED=true
```

---

## SSL Management

```bash
# Check certificate status
docker compose -f docker-compose.production.yml run --rm certbot certificates

# Force renewal
docker compose -f docker-compose.production.yml run --rm certbot renew --force-renewal
docker compose -f docker-compose.production.yml exec nginx nginx -s reload
```

---

## Backup

```bash
# Backup database
docker compose -f docker-compose.production.yml exec app \
    cp /app/data/evidence_custodian.db /app/data/backup_$(date +%Y%m%d).db

# Copy backup locally
docker cp evidence-app:/app/data/backup_$(date +%Y%m%d).db ./
```

---

## Troubleshooting

**502 Bad Gateway?**
```bash
docker compose -f docker-compose.production.yml logs app
docker compose -f docker-compose.production.yml restart app
```

**SSL not working?**
```bash
docker compose -f docker-compose.production.yml exec nginx nginx -t
docker compose -f docker-compose.production.yml run --rm certbot certificates
```

**Container keeps restarting?**
```bash
docker compose -f docker-compose.production.yml logs --tail=50 app
```

---

## Volumes

| Volume | Purpose |
|--------|---------|
| evidence-data | SQLite database |
| evidence-uploads | Uploaded evidence files |
| evidence-output | Generated certificates |
| evidence-logs | Application logs |
| certbot-etc | SSL certificates |

---

## Update Procedure

```bash
cd /opt/evidence-custodian

# Backup first!
./backup.sh

# Update files
# ... upload new files or git pull ...

# Rebuild and restart
docker compose -f docker-compose.production.yml build --no-cache
docker compose -f docker-compose.production.yml up -d
```
